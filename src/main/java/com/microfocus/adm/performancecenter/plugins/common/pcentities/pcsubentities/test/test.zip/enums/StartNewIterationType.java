package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum  StartNewIterationType {


    IMMEDIATELY("immediately"),
    FIXED_DELAY("fixed delay"),
    RANDOM_DELAY("random delay"),
    FIXED_INTERVAL("fixed interval"),
    RANDOM_INTERVAL("random interval");

    private String value;

    private StartNewIterationType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static StartNewIterationType get(String val){
        for (StartNewIterationType startNewIterationType : StartNewIterationType.values()) {
            if (val.equals(startNewIterationType.value()))
                return startNewIterationType;
        }
        return null;
    }

}
