package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum StartStopVusersType {
    SUMULTANEOUSLY("simultaneously"),
    GRADUALLY("gradually");

    private String value;

    private StartStopVusersType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static StartStopVusersType get(String val){
        for (StartStopVusersType startStopVusersType : StartStopVusersType.values()) {
            if (val.equals(startStopVusersType.value()))
                return startStopVusersType;
        }
        return null;
    }

}
