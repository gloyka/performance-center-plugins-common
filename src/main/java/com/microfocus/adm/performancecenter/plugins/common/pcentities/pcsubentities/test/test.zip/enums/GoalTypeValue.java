package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum GoalTypeValue {

    VIRTUAL_USERS("VirtualUsers"),
    HITS_PER_SECOND("HitsPerSecond"),
    TRANSACTIONS_PER_SECOND("TransactionsPerSecond");

    private String value;

    private GoalTypeValue(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static GoalTypeValue get(String val){
        for (GoalTypeValue goalTypeValue : GoalTypeValue.values()) {
            if (val.equals(goalTypeValue.value()))
                return goalTypeValue;
        }
        return null;
    }

}
