package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum ThinkTimeType {
    IGNORE("ignore"),
    REPLAY("replay"),
    MODIFY("modify"),
    RANDOM("random");

    private String value;

    private ThinkTimeType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }

    public static ThinkTimeType get(String val){
        for (ThinkTimeType ThinkTimeType : ThinkTimeType.values()) {
            if (val.equals(ThinkTimeType.value()))
                return ThinkTimeType;
        }
        return null;
    }
}
