package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum LogOptionsType {

    ON_ERROR("on error"),
    ALWAYS("always");

    private String value;

    private LogOptionsType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static LogOptionsType get(String val){
        for (LogOptionsType logOptionsType : LogOptionsType.values()) {
            if (val.equals(logOptionsType.value()))
                return logOptionsType;
        }
        return null;
    }
}
