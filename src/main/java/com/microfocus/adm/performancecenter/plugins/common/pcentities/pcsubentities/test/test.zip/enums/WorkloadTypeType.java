package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum WorkloadTypeType {

    BASIC("basic"),
    REAL_WORLD("real-world"),
    GOAL_ORIENTED("goal oriented");

    private String value;

    private WorkloadTypeType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static WorkloadTypeType get(String val) {
        for (WorkloadTypeType workloadTypeType : WorkloadTypeType.values()) {
            if (val.equals(workloadTypeType.value()))
                return workloadTypeType;
        }
        return null;
    }

}
