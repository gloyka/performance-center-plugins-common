package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum LGDistributionType {

    ALL_TO_EACH_GROUP("all to each group"),
    MANUAL("manual");

    private String value;

    private LGDistributionType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static LGDistributionType get(String val){
        for (LGDistributionType lgDistributionType : LGDistributionType.values()) {
            if (val.equals(lgDistributionType.value()))
                return lgDistributionType;
        }
        return null;
    }

}
