package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.rts.thinktime;

import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.rts.pacing.startnewiteration.StartNewIteration;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums.ThinkTimeType;
import com.microfocus.adm.performancecenter.plugins.common.utils.Helper;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import lombok.Getter;
import lombok.Setter;

import javax.xml.bind.annotation.*;

@Setter
@Getter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="ThinkTime")
public class ThinkTime {

    @XmlAttribute
    @XStreamAsAttribute
    private String Type;

    @XmlElement
    @XStreamAlias("MinPercentage")
    private int MinPercentage;

    @XmlElement
    @XStreamAlias("MaxPercentage")
    private int MaxPercentage;

    @XmlElement
    @XStreamAlias("LimitThinkTimeSeconds")
    private int LimitThinkTimeSeconds;

    public ThinkTime(String type, int minPercentage, int maxPercentage, int limitThinkTimeSeconds) {
        setType(type);
        setMinPercentage(minPercentage);
        setMaxPercentage(maxPercentage);
        setLimitThinkTimeSeconds(limitThinkTimeSeconds);
    }

    public ThinkTime(ThinkTimeType type, int minPercentage, int maxPercentage, int limitThinkTimeSeconds) {
        setType(type);
        setMinPercentage(minPercentage);
        setMaxPercentage(maxPercentage);
        setLimitThinkTimeSeconds(limitThinkTimeSeconds);
    }

    public void setType (String type) {
        this.Type = type;
    }

    public void setType (ThinkTimeType type) {
        this.Type = type.value();
    }

    @Override
    public String toString() {
        return "ThinkTime{" + "Type = " + Type +
                ", MinPercentage = " + MinPercentage +
                ", MaxPercentage = " + MaxPercentage +
                ", LimitThinkTimeSeconds = " + LimitThinkTimeSeconds +
                "}";
    }

    public String objectToXML() {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        xstream.alias("ThinkTime", ThinkTime.class);
        xstream.useAttributeFor(ThinkTime.class, "Type");
        xstream.aliasField("Type", ThinkTime.class, "Type");
        xstream.aliasField("MinPercentage", ThinkTime.class, "MinPercentage");
        xstream.aliasField("MaxPercentage", ThinkTime.class, "MaxPercentage");
        xstream.aliasField("LimitThinkTimeSeconds", ThinkTime.class, "LimitThinkTimeSeconds");
        xstream.aliasField("ThinkTime", ThinkTime.class, "ThinkTime");
        xstream.setMode(XStream.NO_REFERENCES);
        return xstream.toXML(this);
    }

    public static ThinkTime xmlToObject(String xml) {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        xstream.useAttributeFor(ThinkTime.class, "Type");
        xstream.aliasField("Type", ThinkTime.class, "Type");
        xstream.alias("ThinkTime" , ThinkTime.class);
        xstream.setClassLoader(ThinkTime.class.getClassLoader());
        xstream.setMode(XStream.NO_REFERENCES);
        return (ThinkTime)xstream.fromXML(xml);
    }

}
