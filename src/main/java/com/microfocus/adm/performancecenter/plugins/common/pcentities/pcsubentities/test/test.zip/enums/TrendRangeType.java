package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

import com.microfocus.adm.performancecenter.plugins.common.pcentities.RunState;


public enum TrendRangeType {

    COMPLETE_RUN("CompleteRun"),
    PART_OF_RUN("PartOfRun");

    private String value;

    private TrendRangeType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }

    public static TrendRangeType get(String val){
        for (TrendRangeType trendRangeType : TrendRangeType.values()) {
            if (val.equals(trendRangeType.value()))
                return trendRangeType;
        }
        return null;
    }

}


