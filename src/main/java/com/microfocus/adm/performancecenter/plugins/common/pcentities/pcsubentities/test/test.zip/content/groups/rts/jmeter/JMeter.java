package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.rts.jmeter;

import com.microfocus.adm.performancecenter.plugins.common.utils.Helper;
import com.thoughtworks.xstream.XStream;
import lombok.Getter;
import lombok.Setter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Setter
@Getter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="JMeter")
public class JMeter {

    @XmlElement
    private boolean StartMeasurements;

    @XmlElement
    private String JMeterHomePath;

    @XmlElement
    private boolean JMeterUseDefaultPort;

    @XmlElement
    private int JMeterMinPort;

    @XmlElement
    private int JMeterMaxPort;

    public JMeter() {}

    public JMeter(boolean startMeasurements, String JMeterHomePath, boolean JMeterUseDefaultPort, int JMeterMinPort, int JMeterMaxPort) {
        setStartMeasurements(startMeasurements);
        setJMeterHomePath(JMeterHomePath);
        setJMeterUseDefaultPort(JMeterUseDefaultPort);
        setJMeterMinPort(JMeterMinPort);
        setJMeterMaxPort(JMeterMaxPort);
    }


    @Override
    public String toString() {
        return "JMeter{" + "StartMeasurements = " + StartMeasurements +
                ", JMeterHomePath = " + JMeterHomePath +
                ", JMeterUseDefaultPort = " + JMeterUseDefaultPort +
                ", JMeterMinPort = " + JMeterMinPort +
                ", JMeterMaxPort = " + JMeterMaxPort + "}";
    }

    public String objectToXML() {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        xstream.alias("JMeter", JMeter.class);
        xstream.aliasField("StartMeasurements", JMeter.class, "StartMeasurements");
        xstream.aliasField("JMeterHomePath", JMeter.class, "JMeterHomePath");
        xstream.aliasField("JMeterUseDefaultPort", JMeter.class, "JMeterUseDefaultPort");
        xstream.aliasField("JMeterMinPort", JMeter.class, "JMeterMinPort");
        xstream.aliasField("JMeterMaxPort", JMeter.class, "JMeterMaxPort");
        xstream.aliasField("JMeter", JMeter.class, "JMeter");
        xstream.setMode(XStream.NO_REFERENCES);
        return xstream.toXML(this);
    }

    public static JMeter xmlToObject(String xml)
    {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        xstream.alias("JMeter" , JMeter.class);
        xstream.setClassLoader(JMeter.class.getClassLoader());
        xstream.setMode(XStream.NO_REFERENCES);
        return (JMeter)xstream.fromXML(xml);
    }

}
