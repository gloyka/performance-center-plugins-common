package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum InitializeType {

    GRADUALLY("gradually"),
    JUST_BEFORE_VUSER_RUNS("just before vuser runs"),
    SIMULTANEOUSLY("simultaneously");

    private String value;

    private InitializeType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static InitializeType get(String val){
        for (InitializeType initializeType : InitializeType.values()) {
            if (val.equals(initializeType.value()))
                return initializeType;
        }
        return null;
    }

}
