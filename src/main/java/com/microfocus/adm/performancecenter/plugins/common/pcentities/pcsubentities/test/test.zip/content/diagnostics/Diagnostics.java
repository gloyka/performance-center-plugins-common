package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.diagnostics;

import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.automatictrending.AutomaticTrending;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.diagnostics.j2eedotnet.J2EEDotNet;

import com.microfocus.adm.performancecenter.plugins.common.utils.Helper;
import com.thoughtworks.xstream.XStream;
import lombok.Setter;
import lombok.Getter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Setter
@Getter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="Diagnostics")
public class Diagnostics
{
    @XmlElement
    private boolean EnableWebPage;

    @XmlElement
    private boolean Enabled;

    @XmlElement
    private J2EEDotNet J2EEDotNet;

    @XmlElement
    private String VusersPercentage;

    public Diagnostics() {}

    public Diagnostics(boolean enableWebPage, boolean enabled, J2EEDotNet j2EEDotNet, String vusersPercentage) {
        setEnableWebPage(enableWebPage);
        setEnabled(enabled);
        setJ2EEDotNet(j2EEDotNet);
        setVusersPercentage(vusersPercentage);
    }


    @Override
    public String toString() {
        return "Diagnostics{" + "EnableWebPage = " + EnableWebPage +
                ", Enabled = " + Enabled +
                ", J2EEDotNet = " + J2EEDotNet +
                ", VusersPercentage = " + VusersPercentage + "}";
    }


    public String objectToXML() {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        //xstream.useAttributeFor(Content.class, "xmlns");
        xstream.alias("Diagnostics", Diagnostics.class);
        xstream.aliasField("EnableWebPage", Diagnostics.class, "EnableWebPage");
        xstream.aliasField("Enabled", Diagnostics.class, "Enabled");
        xstream.aliasField("J2EEDotNet", Diagnostics.class, "J2EEDotNet");
        xstream.aliasField("VusersPercentage", Diagnostics.class, "VusersPercentage");
        xstream.aliasField("Diagnostics", Diagnostics.class, "Diagnostics");
        xstream.setMode(XStream.NO_REFERENCES);
        return xstream.toXML(this);
    }

    public static Diagnostics xmlToObject(String xml)
    {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        xstream.alias("Diagnostics" , Diagnostics.class);
        xstream.setClassLoader(Diagnostics.class.getClassLoader());
        xstream.setMode(XStream.NO_REFERENCES);
        return (Diagnostics)xstream.fromXML(xml);
    }
}
