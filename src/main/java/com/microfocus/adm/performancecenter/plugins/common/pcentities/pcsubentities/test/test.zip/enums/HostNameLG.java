package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum HostNameLG {

    LG1("LG1"),
    LG2("LG2"),
    LG3("LG3"),
    LG4("LG4"),
    LG5("LG5");

    private String value;

    private HostNameLG(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static HostNameLG get(String val){
        for (HostNameLG hostNameLG : HostNameLG.values()) {
            if (val.equals(hostNameLG.value()))
                return hostNameLG;
        }
        return null;
    }
}
