package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum HostNameDynamic {

    DOCKER1("DOCKER1"),
    DOCKER2("DOCKER2"),
    DOCKER3("DOCKER3"),
    DOCKER4("DOCKER4"),
    DOCKER5("DOCKER5");

    private String value;

    private HostNameDynamic(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static HostNameDynamic get(String val){
        for (HostNameDynamic hostNameDynamic : HostNameDynamic.values()) {
            if (val.equals(hostNameDynamic.value()))
                return hostNameDynamic;
        }
        return null;
    }


}
