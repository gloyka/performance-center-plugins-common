package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum DurationType {

    INDEFINITELY("indefinitely"),
    RUN_FOR("run for"),
    UNTIL_COMPLETE("until complete");

    private String value;

    private DurationType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static DurationType get(String val){
        for (DurationType durationType : DurationType.values()) {
            if (val.equals(durationType.value()))
                return durationType;
        }
        return null;
    }

}
