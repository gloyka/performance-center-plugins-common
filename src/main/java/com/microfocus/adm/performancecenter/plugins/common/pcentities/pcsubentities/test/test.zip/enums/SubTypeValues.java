package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum SubTypeValues {

    BY_TEST("by test"),
    BY_GROUP("by group");

    private String value;

    private SubTypeValues(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static SubTypeValues get(String val) {
        for (SubTypeValues subTypeValues : SubTypeValues.values()) {
            if (val.equals(subTypeValues.value()))
                return subTypeValues;
        }
        return null;
    }

}
