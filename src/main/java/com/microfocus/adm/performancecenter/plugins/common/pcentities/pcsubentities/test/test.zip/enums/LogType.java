package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum LogType {

    IGNORE("ignore"),
    STANDARD("standard"),
    EXTENDED("extended");

    private String value;

    private LogType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static LogType get(String val){
        for (LogType logType : LogType.values()) {
            if (val.equals(logType.value()))
                return logType;
        }
        return null;
    }


}
