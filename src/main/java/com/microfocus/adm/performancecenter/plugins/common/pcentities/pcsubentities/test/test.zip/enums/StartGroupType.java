package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum StartGroupType {

    IMMEDIATELY("immediately"),
    WITH_DELAY("with delay"),
    WHEN_GROUP_FINISHES("when group finishes");

    private String value;

    private StartGroupType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static StartGroupType get(String val){
        for (StartGroupType startGroupType : StartGroupType.values()) {
            if (val.equals(startGroupType.value()))
                return startGroupType;
        }
        return null;
    }
}
