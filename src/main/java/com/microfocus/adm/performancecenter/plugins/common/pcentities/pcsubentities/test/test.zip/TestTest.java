package com.microfocus.adm.performancecenter.plugins.common.rest;

import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.Test;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.Content;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.analysistemplate.AnalysisTemplate;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.automatictrending.AutomaticTrending;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.diagnostics.Diagnostics;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.diagnostics.j2eedotnet.J2EEDotNet;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.globalcommandline.GlobalCommandLine;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.globalcommandline.commandline.CommandLine;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.globalrts.GlobalRTS;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.goalscheduler.GoalScheduler;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.goalscheduler.goalhitspersecond.GoalHitsPerSecond;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.goalscheduler.goaltransactionspersecond.GoalTransactionsPerSecond;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.goalscheduler.goalvirtualusers.GoalVirtualUsers;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.goalscheduler.scenariosettings.ScenarioSettings;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.goalscheduler.scenariosettings.runtimeaftergoalachieved.RunTimeAfterGoalAchieved;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.Group;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.host.Host;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.rts.RTS;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.rts.javavm.JavaVM;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.rts.javavm.javaenvclasspaths.JavaEnvClassPaths;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.rts.jmeter.JMeter;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.rts.log.Log;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.rts.log.logoptions.LogOptions;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.rts.pacing.Pacing;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.rts.pacing.startnewiteration.StartNewIteration;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.rts.thinktime.ThinkTime;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.groups.script.Script;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.lgdistribution.LGDistribution;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.monitorprofiles.MonitorProfile;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.monitorsofw.MonitorOFW;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.scheduler.Scheduler;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.scheduler.actions.Action;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.scheduler.actions.common.Ramp;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.scheduler.actions.common.TimeInterval;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.scheduler.actions.duration.Duration;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.scheduler.actions.initialize.Initialize;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.scheduler.actions.startgroup.StartGroup;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.scheduler.actions.startvusers.StartVusers;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.scheduler.actions.stopvusers.StopVusers;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.SLA;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.averagehitspersecond.AverageHitsPerSecond;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.averagethroughput.AverageThroughput;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.common.Thresholds.Thresholds;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.common.Thresholds.betweenthreshold.BetweenThreshold;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.common.loadvalues.LoadValues;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.common.loadvalues.betweens.Between;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.errorspersecond.ErrorsPerSecond;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.totalhits.TotalHits;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.totalthroughput.TotalThroughput;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.common.transactions.Transaction;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.transactionresponsetimeaverage.TransactionResponseTimeAverage;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.sla.transactionresponsetimepercentile.TransactionResponseTimePercentile;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.workloadtype.WorkloadType;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums.*;
import org.junit.Before;
//import org.junit.Test;

import javax.xml.bind.*;
import java.util.ArrayList;

public class TestTest {
    private JAXBContext context;

    @Before
    public void init() throws JAXBException {
//    this.context = JAXBContext.newInstance(Test.class);
}

    @org.junit.Test
    public void serialization() throws JAXBException {


        /* verifying Test */
            /* verifying Content */

                /* verifying AnalysisTemplate */
                    AnalysisTemplate analysisTemplate = new AnalysisTemplate(4);
                    String xmlAnalysisTemplate = analysisTemplate.objectToXML();
                    AnalysisTemplate analysisTemplate2 = AnalysisTemplate.xmlToObject(xmlAnalysisTemplate);
                    String xmlAnalysisTemplate2 = analysisTemplate2.objectToXML();
                    verifyXML(xmlAnalysisTemplate, xmlAnalysisTemplate2);
                /* verified AnalysisTemplate */

                /* verifying AutomaticTrending */
                    AutomaticTrending automaticTrending = new AutomaticTrending(2, 10, TrendRangeType.COMPLETE_RUN, MaxRunsReachedOption.DO_NOT_PUBLISH_ADDITIONAL_RUNS);
                    String xmlAutomaticTrending = automaticTrending.objectToXML();
                    AutomaticTrending automaticTrending2 = AutomaticTrending.xmlToObject(xmlAutomaticTrending);
                    String xmlAutomaticTrending2 = automaticTrending2.objectToXML();
                    verifyXML(xmlAutomaticTrending, xmlAutomaticTrending2);
                /* verified AutomaticTrending */

                /* verifying Diagnostics */
                    /* verifying J2EEDotNet */
                        J2EEDotNet j2EEDotNet = new J2EEDotNet(true, "", false, true);
                        String xmlJ2EEDotNet = j2EEDotNet.objectToXML();
                        J2EEDotNet j2EEDotNet2 = J2EEDotNet.xmlToObject(xmlJ2EEDotNet);
                        String xmlJ2EEDotNet2 = j2EEDotNet2.objectToXML();
                        verifyXML(xmlJ2EEDotNet, xmlJ2EEDotNet2);
                    /* verified J2EEDotNet */

                    //verifying Diagnostics
                    Diagnostics diagnostics = new Diagnostics(true, true, j2EEDotNet, "34");
                    String xmlDiagnostics = diagnostics.objectToXML();
                    Diagnostics diagnostics2 = Diagnostics.xmlToObject(xmlDiagnostics);
                    String xmlDiagnostics2 = diagnostics2.objectToXML();
                    verifyXML(xmlDiagnostics, xmlDiagnostics2);
                /* verified Diagnostics */

                /* verifying GlobalCommandLine */
                    /* verifying CommandLine */
                        String commandLineName1 = "CMD1";
                        String commandLineName2 = "CMD2";
                        String commandLineValue1 = "Command line 1";
                        String commandLineValue2 = "Command line 2";
                        CommandLine firstCommandLine = new CommandLine(commandLineName1, commandLineValue1);
                        String xmlFirstCommandLine = firstCommandLine.objectToXML();
                        CommandLine firstCommandLine2 = CommandLine.xmlToObject(xmlFirstCommandLine);
                        String xmlFirstCommandLine2 = firstCommandLine2.objectToXML();
                        verifyXML(xmlFirstCommandLine, xmlFirstCommandLine2);
                        CommandLine secondCommandLine = new CommandLine(commandLineName2, commandLineValue2);
                        String xmlSecondCommandLine = secondCommandLine.objectToXML();
                        CommandLine secondCommandLine2 = CommandLine.xmlToObject(xmlSecondCommandLine);
                        String xmlSecondCommandLine2 = secondCommandLine2.objectToXML();
                        verifyXML(xmlSecondCommandLine, xmlSecondCommandLine2);
                    /* verified CommandLine */

                    //verifying GlobalCommandLine
                    ArrayList<CommandLine> commandLinesArrayList = new ArrayList<CommandLine>();
                    commandLinesArrayList.add(firstCommandLine);
                    commandLinesArrayList.add(firstCommandLine2);
                    commandLinesArrayList.add(secondCommandLine);
                    commandLinesArrayList.add(secondCommandLine2);
                    GlobalCommandLine globalCommandLine = new GlobalCommandLine(commandLinesArrayList);
                    String xmlGlobalCommandLine = globalCommandLine.objectToXML();
                    GlobalCommandLine globalCommandLine2 = GlobalCommandLine.xmlToObject(xmlGlobalCommandLine);
                    String xmlGlobalCommandLine2 = globalCommandLine2.objectToXML();
                    verifyXML(xmlGlobalCommandLine, xmlGlobalCommandLine2);
                /* verified GlobalCommandLine */

                /*verifying Groups*/
                    /* verifying Host */
                        Host hostFirst = new Host(HostNameLG.LG1, HostType.AUTOMATCH);
                        String xmlHostFirst = hostFirst.objectToXML();
                        Host hostFirst2 = Host.xmlToObject(xmlHostFirst);
                        String xmlHostFirst2 = hostFirst2.objectToXML();
                        verifyXML(xmlHostFirst, xmlHostFirst2);

                        Host hostSecond = new Host(HostNameDynamic.DOCKER1, HostType.DYNAMIC);
                        String xmlHostSecond = hostSecond.objectToXML();
                        Host hostSecond2 = Host.xmlToObject(xmlHostSecond);
                        String xmlHostSecond2 = hostSecond2.objectToXML();
                        verifyXML(xmlHostSecond, xmlHostSecond2);

                        Host hostThird = new Host("MyHostName", HostType.SPECIFIC);
                        String xmlHostThird = hostThird.objectToXML();
                        Host hostThird2 = Host.xmlToObject(xmlHostThird);
                        String xmlHostThird2 = hostThird2.objectToXML();
                        verifyXML(xmlHostThird, xmlHostThird2);
                    /* verified Host */


                    /* verifying RTS */
                        /* verifying Log */
                            /* verifying LogOptions */
                                LogOptions logOptions = new LogOptions(LogOptionsType.ALWAYS, 10);
                                String xmlLogOptions = logOptions.objectToXML();
                                LogOptions logOptions2 = LogOptions.xmlToObject(xmlLogOptions);
                                String xmlLogOptions2 = logOptions2.objectToXML();
                                verifyXML(xmlLogOptions, xmlLogOptions2);
                            /* verified LogOptions */
                            //verifying Log
                            Log log = new Log(LogType.EXTENDED, true, true, true, logOptions);
                            String xmlLog = log.objectToXML();
                            Log log2 = Log.xmlToObject(xmlLog);
                            String xmlLog2 = log2.objectToXML();
                            verifyXML(xmlLog, xmlLog2);
                        /* verified Log */
                        /* Verifying pacing */
                            /* Verifying StartNewIteration */
                                int delayAtRangeOfSeconds = 10;
                                int delayAtRangeToSeconds = 20;
                                StartNewIteration startNewIteration = new StartNewIteration(StartNewIterationType.RANDOM_INTERVAL, delayAtRangeOfSeconds, delayAtRangeToSeconds);
                                String xmlStartNewIteration = startNewIteration.objectToXML();
                                StartNewIteration startNewIteration2 = StartNewIteration.xmlToObject(xmlStartNewIteration);
                                String xmlStartNewIteration2 = startNewIteration2.objectToXML();
                                verifyXML(xmlStartNewIteration, xmlStartNewIteration2);
                            /* Verified StartNewIteration */
                            //Verifying pacing
                            Pacing pacing = new Pacing(10, startNewIteration);
                            String xmlPacing = pacing.objectToXML();
                            Pacing pacing2 = Pacing.xmlToObject(xmlPacing);
                            String xmlPacing2 = pacing2.objectToXML();
                            verifyXML(xmlPacing, xmlPacing2);
                        /* Verified pacing */
                        /* Verifying ThinkTime */
                            ThinkTime thinkTime = new ThinkTime(ThinkTimeType.RANDOM, 50, 150, 10);
                            String xmlThinkTime = thinkTime.objectToXML();
                            ThinkTime thinkTime2 = ThinkTime.xmlToObject(xmlThinkTime);
                            String xmlThinkTime2 = thinkTime2.objectToXML();
                            verifyXML(xmlThinkTime, xmlThinkTime2);
                        /* Verified ThinkTime */
                        /* verifying JavaVM */
                            /* verifying JavaEnvClassPaths */
                                String JavaEnvClassPath = "user_binaries\\C__Users_my_user_Desktop_VugenScriptConverterCustomerIssue\\junit-1.0-SNAPSHOT.jar";
                                JavaEnvClassPaths javaEnvClassPaths = new JavaEnvClassPaths(JavaEnvClassPath);
                                String xmlJavaEnvClassPaths = javaEnvClassPaths.objectToXML();
                                JavaEnvClassPaths javaEnvClassPaths2 = JavaEnvClassPaths.xmlToObject(xmlJavaEnvClassPaths);
                                String xmlJavaEnvClassPaths2 = javaEnvClassPaths2.objectToXML();
                                verifyXML(xmlJavaEnvClassPaths, xmlJavaEnvClassPaths2);
                            /* verified JavaEnvClassPaths */
                            //verifying JavaVM
                            boolean userSpecifiedJdk = true;
                            String jdkHome = "my_jdk_path";
                            String javaVmParameters = "some_parameters_here";
                            boolean useXboot = true;
                            boolean enableClassLoaderPerVuser = false;
                            JavaVM javaVM = new JavaVM(javaEnvClassPaths, userSpecifiedJdk, jdkHome, javaVmParameters, useXboot, enableClassLoaderPerVuser);
                            String xmljavaVM = javaVM.objectToXML();
                            JavaVM javaVM2 = JavaVM.xmlToObject(xmljavaVM);
                            String xmljavaVM2 = javaVM2.objectToXML();
                            verifyXML(xmljavaVM, xmljavaVM2);
                        /* verified JavaVM */
                        /* verifying JMeter */
                            boolean startMeasurements = true;
                            String jMeterHomePath = "Some Path";
                            boolean jMeterUseDefaultPort = false;
                            int jMeterMinPort = 2000;
                            int jMeterMaxPort = 3000;

                            JMeter jMeter = new JMeter(startMeasurements, jMeterHomePath, jMeterUseDefaultPort, jMeterMinPort, jMeterMaxPort);
                            String xmlJmeter = jMeter.objectToXML();
                            JMeter jMeter2 = JMeter.xmlToObject(xmlJmeter);
                            String xmlJmeter2 = jMeter2.objectToXML();
                            verifyXML(xmlJmeter, xmlJmeter2);
                        /* verified JMeter */


                        //verifying RTS
                        RTS rts = new RTS(pacing, thinkTime, log, jMeter, javaVM);
                        String xmlRTS = rts.objectToXML();
                        RTS rts2 = RTS.xmlToObject(xmlRTS);
                        String xmlRTS2 = rts2.objectToXML();
                        verifyXML(xmlRTS, xmlRTS2);

                        //verifying partial RTS
                        RTS rtsPartial = new RTS("kuku", pacing, null, null, null, null);
                        String xmlRTSPartial = rtsPartial.objectToXML();
                        RTS rtsPartial2 = RTS.xmlToObject(xmlRTSPartial);
                        String xmlRTSPartial2 = rtsPartial2.objectToXML();
                        verifyXML(xmlRTSPartial, xmlRTSPartial2);

                    /* verified RTS */

                    /* Verifying script */
                        int scriptId = 3;
                        Script script = new Script(scriptId);
                        String xmlScript = script.objectToXML();
                        Script script2 = Script.xmlToObject(xmlScript);
                        String xmlScript2 = script2.objectToXML();
                        verifyXML(xmlScript, xmlScript2);
                    /* Verified script */


                    /* Verifying Host */
                        Host firstHost = new Host(HostNameDynamic.DOCKER1, HostType.DYNAMIC );
                        String xmlFirstHost = firstHost.objectToXML();
                        Host firstHost2 = Host.xmlToObject(xmlFirstHost);
                        String xmlFirstHost2 = firstHost2.objectToXML();
                        verifyXML(xmlFirstHost, xmlFirstHost2);

                        Host secondHost = new Host(HostNameLG.LG1, HostType.AUTOMATCH );
                        String xmlSecondHost = secondHost.objectToXML();
                        Host secondHost2 = Host.xmlToObject(xmlSecondHost);
                        String xmlSecondHost2 = secondHost2.objectToXML();
                        verifyXML(xmlSecondHost, xmlSecondHost2);

                        ArrayList<Host> hosts = new ArrayList<Host>();
                        hosts.add(firstHost);
                        hosts.add(secondHost);

                    /* Verified Host */

                    //verifying Group
                    String groupName1 = "group1";
                    String groupName2 = "group1";
                    int vusers = 10;
                    String globalRTSAll="All";
                    String globalRTSFirst="first";
                    String globalRTSsecond="second";
                    String globalRTSThird="Third";
                    String globalRTSFourth="Fourth";
                    String globalRTSFifth="Fifth";

                    Group group = new Group(groupName1, vusers, script, hosts, rts, globalRTSFifth, commandLineName1);
                    String xmlGroup = group.objectToXML();
                    Group group2 = Group.xmlToObject(xmlGroup);
                    String xmlGroup2 = group2.objectToXML();
                    verifyXML(xmlGroup, xmlGroup2);
                /* verified Groups */


                /* Verifying GlobalRTS */
                    //creating RTS for GlobalRTS

                    ArrayList<RTS> rtsList = new ArrayList<RTS>();
                    rtsList.add(new RTS(globalRTSAll, pacing, thinkTime, log, jMeter, javaVM));
                    rtsList.add(new RTS(globalRTSFirst, pacing, null, null, null, null));
                    rtsList.add(new RTS(globalRTSsecond, null, thinkTime, null, null, null));
                    rtsList.add(new RTS(globalRTSThird, null, null, log, null, null));
                    rtsList.add(new RTS(globalRTSFourth, null, null, null, jMeter, null));
                    rtsList.add(new RTS(globalRTSFifth, null, null, null, null, javaVM));

                    //Verifying GlobalRTS
                    GlobalRTS globalRTS = new GlobalRTS(rtsList);
                    String xmlGlobalRTS = globalRTS.objectToXML();
                    GlobalRTS globalRTS2 = GlobalRTS.xmlToObject(xmlGlobalRTS);
                    String xmlGlobalRTS2 = globalRTS2.objectToXML();
                    verifyXML(xmlGlobalRTS, xmlGlobalRTS2);

                /* Verified GlobalRTS */

                /* verifying LGDistribution */
                    LGDistribution lgDistribution = new LGDistribution(LGDistributionType.ALL_TO_EACH_GROUP, 2);
                    String xmlLGDistribution = lgDistribution.objectToXML();
                    LGDistribution lgDistribution2 = LGDistribution.xmlToObject(xmlLGDistribution);
                    String xmlLGDistribution2 = lgDistribution2.objectToXML();
                    verifyXML(xmlLGDistribution,xmlLGDistribution2);
                /* verified LGDistribution */


                /* verifying MonitorProfile */
                    MonitorProfile monitorProfile = new MonitorProfile(2);
                    String xmlMonitorProfile = monitorProfile.objectToXML();
                    MonitorProfile monitorProfile2 = MonitorProfile.xmlToObject(xmlMonitorProfile);
                    String xmlMonitorProfile2 = monitorProfile2.objectToXML();
                    verifyXML(xmlMonitorProfile,xmlMonitorProfile2);
                /* verified MonitorProfile */

                /* verifying monitorOFW */
                    MonitorOFW monitorOFW = new MonitorOFW(2);
                    String xmlMonitorOFW = monitorOFW.objectToXML();
                    MonitorOFW monitorOFW2 = MonitorOFW.xmlToObject(xmlMonitorOFW);
                    String xmlMonitorOFW2 = monitorOFW2.objectToXML();
                    verifyXML(xmlMonitorOFW,xmlMonitorOFW2);
                /* verified monitorOFW */

                /* Verifying Scheduler */
                    /* Verifying Action */
                        /* Verifying Ramp */
                            /* verifying TimeInterval */
                                int timeIntervalHours =10;
                                int timeIntervalMinutes =10;
                                int timeIntervalSeconds =10;
                                TimeInterval timeInterval = new TimeInterval(timeIntervalHours, timeIntervalMinutes, timeIntervalSeconds);
                                String xmlTimeInterval = timeInterval.objectToXML();
                                TimeInterval timeInterval2 = TimeInterval.xmlToObject(xmlTimeInterval);
                                String xmlTimeInterval2 = timeInterval2.objectToXML();
                                verifyXML(xmlTimeInterval, xmlTimeInterval2);
                            /* verified TimeInterval */

                            int rampVusers = 10;
                            Ramp ramp = new Ramp(rampVusers, timeInterval);
                            String xmlRamp = ramp.objectToXML();
                            Ramp ramp2 = Ramp.xmlToObject(xmlRamp);
                            String xmlRamp2 = ramp2.objectToXML();
                            verifyXML(xmlRamp, xmlRamp2);
                        /* Verified Ramp */

                        /* Verifying Duration */
                            Duration duration = new Duration(DurationType.UNTIL_COMPLETE, timeInterval);
                            String xmlDuration = duration.objectToXML();
                            Duration duration2 = Duration.xmlToObject(xmlDuration);
                            String xmlDuration2 = duration2.objectToXML();
                            verifyXML(xmlDuration, xmlDuration2);
                        /* Verified Duration */

                        /* Verifying Initialize */
                            int durationVusers = 10;

                            Initialize initialize = new Initialize(InitializeType.GRADUALLY, durationVusers, timeInterval, timeInterval);
                            String xmlInitialize = initialize.objectToXML();
                            Initialize initialize2 = Initialize.xmlToObject(xmlInitialize);
                            String xmlInitialize2 = initialize2.objectToXML();
                            verifyXML(xmlInitialize, xmlInitialize2);
                        /* Verified Initialize */

                        /* Verifying StartGroup */
                            String startGroupName = "groupName1";
                            StartGroup startGroup = new StartGroup(StartGroupType.IMMEDIATELY, timeInterval, startGroupName);
                            String xmlStartGroup = startGroup.objectToXML();
                            StartGroup startGroup2 = StartGroup.xmlToObject(xmlStartGroup);
                            String xmlStartGroup2 = startGroup2.objectToXML();
                            verifyXML(xmlStartGroup, xmlStartGroup2);
                        /* Verified StartGroup */

                        /* Verifying StartVusers */
                            int startVusersVusers = 12;
                            StartVusers startVusers = new StartVusers(StartStopVusersType.GRADUALLY, startVusersVusers, ramp);
                            String xmlStartVusers = startVusers.objectToXML();
                            StartVusers startVusers2 = StartVusers.xmlToObject(xmlStartVusers);
                            String xmlStartVusers2 = startVusers2.objectToXML();
                            verifyXML(xmlStartVusers, xmlStartVusers2);
                        /* Verified StartVusers */

                        /* Verifying StopVusers */
                            int stopVusersVusers = 12;
                            StopVusers stopVusers = new StopVusers(StartStopVusersType.GRADUALLY, stopVusersVusers, ramp);
                            String xmlStopVusers = stopVusers.objectToXML();
                            StopVusers stopVusers2 = StopVusers.xmlToObject(xmlStopVusers);
                            String xmlStopVusers2 = stopVusers2.objectToXML();
                            verifyXML(xmlStopVusers, xmlStopVusers2);
                        /* Verified StopVusers */

                        //Verifying Action
                        Action action = new Action(initialize,startVusers,duration,stopVusers,startGroup);
                        String xmlAction = action.objectToXML();
                        Action action2 = Action.xmlToObject(xmlAction);
                        String xmlAction2 = action2.objectToXML();
                        verifyXML(xmlAction, xmlAction2);
                     /* Verified Action */
                     //Verifying Scheduler
                    ArrayList<Action> schedulerActions = new ArrayList<Action>();
                    schedulerActions.add(new Action(initialize, null, null, null, null));
                    schedulerActions.add(new Action(null, startVusers, null, null, null));
                    schedulerActions.add(new Action(null, null, duration, null, null));
                    schedulerActions.add(new Action(null, null, null, stopVusers, null));
                    schedulerActions.add(new Action(null, null, null, null, startGroup));

                    Scheduler scheduler = new Scheduler(schedulerActions);
                    String xmlScheduler = scheduler.objectToXML();
                    Scheduler scheduler2 = Scheduler.xmlToObject(xmlScheduler);
                    String xmlScheduler2 = scheduler2.objectToXML();
                    verifyXML(xmlScheduler,xmlScheduler2);

                /* Verified Scheduler */


                /* verifying GoalScheduler */

                    /* verifying GoalHitsPerSecond */
                        int targetHitsPerSecond = 100;
                        int goalHitsPerSecondMinVusers = 30;
                        int goalHitsPerSecondMaxVusers = 60;
                        GoalHitsPerSecond goalHitsPerSecond = new GoalHitsPerSecond(targetHitsPerSecond, goalHitsPerSecondMinVusers, goalHitsPerSecondMaxVusers);
                        String xmlGoalHitsPerSecond = goalHitsPerSecond.objectToXML();
                        GoalHitsPerSecond goalHitsPerSecond2 = GoalHitsPerSecond.xmlToObject(xmlGoalHitsPerSecond);
                        String xmlGoalHitsPerSecond2 = goalHitsPerSecond2.objectToXML();
                        verifyXML(xmlGoalHitsPerSecond, xmlGoalHitsPerSecond2);
                    /* verified GoalHitsPerSecond */

                    /* Verifying GoalTransactionsPerSecond */
                        int targetTransactionsPerSecond = 2;
                        String transactionName = "myTransactionName";
                        int goalTransactionsPerSecondMinVusers = 30;
                        int goalTransactionsPerSecondMaxVusers = 60;
                        GoalTransactionsPerSecond goalTransactionsPerSecond = new GoalTransactionsPerSecond(targetTransactionsPerSecond, transactionName, goalTransactionsPerSecondMinVusers, goalTransactionsPerSecondMaxVusers);
                        String xmlGoalTransactionsPerSecond = goalTransactionsPerSecond.objectToXML();
                        GoalTransactionsPerSecond goalTransactionsPerSecond2 = GoalTransactionsPerSecond.xmlToObject(xmlGoalTransactionsPerSecond);
                        String xmlGoalTransactionsPerSecond2 = goalTransactionsPerSecond2.objectToXML();
                        verifyXML(xmlGoalTransactionsPerSecond, xmlGoalTransactionsPerSecond2);
                    /* Verified GoalTransactionsPerSecond */

                    /* Verifying GoalVirtualUsers */
                        int targetVusersNumber = 30;
                        GoalVirtualUsers goalVirtualUsers = new GoalVirtualUsers(targetVusersNumber);
                        String xmlGoalVirtualUsers = goalVirtualUsers.objectToXML();
                        GoalVirtualUsers goalVirtualUsers2 = GoalVirtualUsers.xmlToObject(xmlGoalVirtualUsers);
                        String xmlGoalVirtualUsers2 = goalVirtualUsers2.objectToXML();
                        verifyXML(xmlGoalVirtualUsers, xmlGoalVirtualUsers2);
                    /* Verified GoalVirtualUsers */

                    /* Verifying ScenarioSettings */
                        /* Verifying RunTimeAfterGoalAchieved */
                            int runTimeAfterGoalAchievedMinutes = 5;
                            RunTimeAfterGoalAchieved runTimeAfterGoalAchieved = new RunTimeAfterGoalAchieved(runTimeAfterGoalAchievedMinutes);
                            String xmlRunTimeAfterGoalAchieved = runTimeAfterGoalAchieved.objectToXML();
                            RunTimeAfterGoalAchieved runTimeAfterGoalAchieved2 = RunTimeAfterGoalAchieved.xmlToObject(xmlRunTimeAfterGoalAchieved);
                            String xmlRunTimeAfterGoalAchieved2 = runTimeAfterGoalAchieved2.objectToXML();
                            verifyXML(xmlRunTimeAfterGoalAchieved, xmlRunTimeAfterGoalAchieved2);
                        /*Verified RunTimeAfterGoalAchieved */

                        //Verifying ScenarioSettings */
                        boolean scenarioSettingsReceiveNotification = true;
                        ScenarioSettings scenarioSettings = new ScenarioSettings(GoalCannotBeReachedActionValues.CONTINUE_WITHOUT_REACHING, runTimeAfterGoalAchieved, scenarioSettingsReceiveNotification);
                        String xmlScenarioSettings = scenarioSettings.objectToXML();
                        ScenarioSettings scenarioSettings2 = ScenarioSettings.xmlToObject(xmlScenarioSettings);
                        String xmlScenarioSettings2 = scenarioSettings2.objectToXML();
                        verifyXML(xmlScenarioSettings, xmlScenarioSettings2);

                    /* Verified ScenarioSettings */

                    //Verifying GoalScheduler
                    String goalProfileName = "HPS_100";
                    GoalTypeValue goalType;
                    boolean doNotChangeScriptThinkTime = true;
                    GoalScheduler goalScheduler = new GoalScheduler(goalProfileName, GoalTypeValue.HITS_PER_SECOND, goalHitsPerSecond, goalTransactionsPerSecond, goalVirtualUsers, doNotChangeScriptThinkTime, scenarioSettings) ;
                    String xmlGoalScheduler = goalScheduler.objectToXML();
                    GoalScheduler goalScheduler2 = GoalScheduler.xmlToObject(xmlGoalScheduler);
                    String xmlGoalScheduler2 = goalScheduler2.objectToXML();
                    verifyXML(xmlGoalScheduler, xmlGoalScheduler2);
                /* Verified GoalScheduler */

                /* Verifying WorkloadType */
                    WorkloadType workloadType = new WorkloadType(WorkloadTypeType.BASIC, VusersDistributionModeValues.BY_NUMBER, SubTypeValues.BY_TEST);
                    String xmlWorkloadType = workloadType.objectToXML();
                    WorkloadType workloadType2 = WorkloadType.xmlToObject(xmlWorkloadType);
                    String xmlWorkloadType2 = workloadType2.objectToXML();
                    verifyXML(xmlWorkloadType, xmlWorkloadType2);
                /* Verified WorkloadType */

                /* Verifying SLA */
                    /* Verifying AverageHitsPerSecond */
                        int averageHitsPerSecondThreshold = 40;
                        AverageHitsPerSecond averageHitsPerSecond = new AverageHitsPerSecond(averageHitsPerSecondThreshold);
                        String xmlAverageHitsPerSecond = averageHitsPerSecond.objectToXML();
                        AverageHitsPerSecond averageHitsPerSecond2 = AverageHitsPerSecond.xmlToObject(xmlAverageHitsPerSecond);
                        String xmlAverageHitsPerSecond2 = averageHitsPerSecond2.objectToXML();
                        verifyXML(xmlAverageHitsPerSecond, xmlAverageHitsPerSecond2);
                    /* Verified AverageHitsPerSecond */
                    /* Verifying AverageThroughput */
                        int averageThroughputThreshold = 90;
                        AverageThroughput averageThroughput = new AverageThroughput(averageThroughputThreshold);
                        String xmlAverageThroughput = averageThroughput.objectToXML();
                        AverageThroughput averageThroughput2 = AverageThroughput.xmlToObject(xmlAverageThroughput);
                        String xmlAverageThroughput2 = averageThroughput2.objectToXML();
                        verifyXML(xmlAverageThroughput, xmlAverageThroughput2);
                    /* Verified AverageThroughput */
                    /* Verifying Between */
                        int betweenFrom = 10;
                        int betweenTo = 20;
                        Between between = new Between(betweenFrom, betweenTo);
                        String xmlBetween = between.objectToXML();
                        Between between2 = Between.xmlToObject(xmlBetween);
                        String xmlBetween2 = between2.objectToXML();
                        verifyXML(xmlBetween, xmlBetween2);
                    /* Verifying Between */

                    /* Verifying LoadValues */
                        int lessThan = 1;
                        ArrayList<Between> betweens = new ArrayList<Between>();
                        betweens.add(new Between(1,25));
                        betweens.add(new Between(25,50));
                        betweens.add(new Between(50,75));
                        int greaterThanOrEqual = 75;

                        LoadValues loadValues = new LoadValues(lessThan, betweens, greaterThanOrEqual);
                        String xmlLoadValues = loadValues.objectToXML();
                        LoadValues loadValues2 = LoadValues.xmlToObject(xmlLoadValues);
                        String xmlLoadValues2 = loadValues2.objectToXML();
                        verifyXML(xmlLoadValues, xmlLoadValues2);
                    /* Verified LoadValues */

                    /* Verify Thresholds */

                        /* Verifying BetweenThreshold */
                            ArrayList<String> BetweenThresholdThresholds = new ArrayList<String>();
                            BetweenThresholdThresholds.add("40");
                            BetweenThresholdThresholds.add("30");
                            BetweenThresholdThresholds.add("40");

                            BetweenThreshold betweenThreshold = new BetweenThreshold(BetweenThresholdThresholds);
                            String xmlBetweenThreshold = betweenThreshold.objectToXML();
                            BetweenThreshold betweenThreshold2 = BetweenThreshold.xmlToObject(xmlBetweenThreshold);
                            String xmlBetweenThreshold2 = betweenThreshold2.objectToXML();
                            verifyXML(xmlBetweenThreshold, xmlBetweenThreshold2);
                        /* Verified BetweenThreshold */

                        //verifying Thresholds
                            int thresholdsLessThanThreshold = 10;
                            int thresholdsGreaterThanOrEqualThreshold = 50;
                            Thresholds thresholds = new Thresholds(thresholdsLessThanThreshold, betweenThreshold, thresholdsGreaterThanOrEqualThreshold);
                            String xmlThresholds = thresholds.objectToXML();
                            Thresholds thresholds2 = Thresholds.xmlToObject(xmlThresholds);
                            String xmlThresholds2 = thresholds2.objectToXML();
                            verifyXML(xmlThresholds, xmlThresholds2);
                    /* Verified Thresholds */

                    /* Verifying ErrorsPerSecond */
                        ErrorsPerSecond errorsPerSecond = new ErrorsPerSecond(LoadCriterionValues.RUNNING_VUSERS,thresholds,loadValues);
                        String xmlErrorsPerSecond = errorsPerSecond.objectToXML();
                        ErrorsPerSecond errorsPerSecond2 = ErrorsPerSecond.xmlToObject(xmlErrorsPerSecond);
                        String xmlErrorsPerSecond2 = errorsPerSecond2.objectToXML();
                        verifyXML(xmlErrorsPerSecond, xmlErrorsPerSecond2);

                    /* Verified ErrorsPerSecond */

                    /* Verifying TotalHits */
                        TotalHits totalHits = new TotalHits(10);
                        String xmlTotalHits = totalHits.objectToXML();
                        TotalHits totalHits2 = TotalHits.xmlToObject(xmlTotalHits);
                        String xmlTotalHits2 = totalHits2.objectToXML();
                        verifyXML(xmlTotalHits, xmlTotalHits2);
                    /* Verified TotalHits */

                    /* Verifying TotalHits */
                        TotalThroughput totalThroughput = new TotalThroughput(10);
                        String xmlTotalThroughput = totalThroughput.objectToXML();
                        TotalThroughput totalThroughput2 = TotalThroughput.xmlToObject(xmlTotalThroughput);
                        String xmlTotalThroughput2 = totalThroughput2.objectToXML();
                        verifyXML(xmlTotalThroughput, xmlTotalThroughput2);
                    /* Verified TotalHits */

                    /* Verifying Transaction with Thresholds */
                        Transaction transactionThresholds = new Transaction("Action_Transaction", thresholds);
                        String xmlTransactionThresholds = transactionThresholds.objectToXML();
                        Transaction transactionThresholds2 = Transaction.xmlToObject(xmlTransactionThresholds);
                        String xmlTransactionThresholds2 = transactionThresholds2.objectToXML();
                        verifyXML(xmlTransactionThresholds, xmlTransactionThresholds2);
                    /* Verified Transaction */

                    /* Verifying Transaction with Threshold */
                        Transaction transactionThreshold = new Transaction("Action_Transaction", 12);
                        String xmlTransactionThreshold = transactionThreshold.objectToXML();
                        Transaction transactionThreshold2 = Transaction.xmlToObject(xmlTransactionThreshold);
                        String xmlTransactionThreshold2 = transactionThreshold2.objectToXML();
                        verifyXML(xmlTransactionThreshold, xmlTransactionThreshold2);
                    /* Verified Transaction */

                    /* Verifying TransactionResponseTimeAverage */
                        ArrayList<Transaction> transactionResponseTimeAverageTransactions = new ArrayList<Transaction>();
                        transactionResponseTimeAverageTransactions.add(new Transaction("Action_Transaction", thresholds));
                        transactionResponseTimeAverageTransactions.add(new Transaction("vuser_end_Transaction", thresholds));
                        transactionResponseTimeAverageTransactions.add(new Transaction("vuser_init_Transaction", thresholds));

                        TransactionResponseTimeAverage transactionResponseTimeAverage = new TransactionResponseTimeAverage(LoadCriterionValues.RUNNING_VUSERS, loadValues, transactionResponseTimeAverageTransactions);
                        String xmlTransactionResponseTimeAverage = transactionResponseTimeAverage.objectToXML();
                        TransactionResponseTimeAverage transactionResponseTimeAverage2 = TransactionResponseTimeAverage.xmlToObject(xmlTransactionResponseTimeAverage);
                        String xmlTransactionResponseTimeAverage2 = transactionResponseTimeAverage2.objectToXML();
                        verifyXML(xmlTransactionResponseTimeAverage, xmlTransactionResponseTimeAverage2);
                    /* Verifying TransactionResponseTimeAverage */

                    /* Verifying TransactionResponseTimePercentile */
                        ArrayList<Transaction> transactionResponseTimePercentileTransactions = new ArrayList<Transaction>();
                        transactionResponseTimePercentileTransactions.add(new Transaction("Action_Transaction", 10));
                        transactionResponseTimePercentileTransactions.add(new Transaction("vuser_end_Transaction", 20));
                        transactionResponseTimePercentileTransactions.add(new Transaction("vuser_init_Transaction", 30));

                        TransactionResponseTimePercentile transactionResponseTimePercentile = new TransactionResponseTimePercentile(transactionResponseTimePercentileTransactions, 100);
                        String xmlTransactionResponseTimePercentile = transactionResponseTimePercentile.objectToXML();
                        TransactionResponseTimePercentile transactionResponseTimePercentile2 = TransactionResponseTimePercentile.xmlToObject(xmlTransactionResponseTimePercentile);
                        String xmlTransactionResponseTimePercentile2 = transactionResponseTimePercentile2.objectToXML();
                        verifyXML(xmlTransactionResponseTimePercentile, xmlTransactionResponseTimePercentile2);
                    /* Verifying TransactionResponseTimePercentile */

                    //Verifying SLA
                    SLA sla = new SLA(averageThroughput, transactionResponseTimeAverage, transactionResponseTimePercentile, averageHitsPerSecond,totalThroughput, errorsPerSecond, totalHits);
                    String xmlSLA = sla.objectToXML();
                    SLA sla2 = SLA.xmlToObject(xmlSLA);
                    String xmlSLA2 = sla2.objectToXML();
                    verifyXML(xmlSLA, xmlSLA2);
                /* Verified SLA */

                //Verifying Content
                ArrayList<MonitorProfile> monotorProfiles = new ArrayList<MonitorProfile>();
                monotorProfiles.add(new MonitorProfile(42));
                monotorProfiles.add(new MonitorProfile(45));
                ArrayList<Group> groups = new ArrayList<Group>();
                ArrayList<MonitorOFW> monitorsOFW = new ArrayList<MonitorOFW>();
                monitorsOFW.add(new MonitorOFW(80));
                monitorsOFW.add(new MonitorOFW(81));
                groups.add(new Group(groupName1, vusers, script, hosts, rts, globalRTSFifth, commandLineName1));
                groups.add(new Group(groupName2, vusers, script, hosts, rts, globalRTSFifth, commandLineName2));

                Content content = new Content("controller", workloadType, lgDistribution, monotorProfiles, groups, scheduler, analysisTemplate, automaticTrending, monitorsOFW, sla, diagnostics);
                String xmlContent = content.objectToXML();
                Content content2 = Content.xmlToObject(xmlContent);
                String xmlContent2 = content2.objectToXML();
                verifyXML(xmlContent, xmlContent2);
            /* Verified Content */

            //verifying creating Test
            Test test = new Test("myNewTest", "Subject\\coucou", content);
            String xmlTest = test.objectToXML();
            Test test2 = Test.xmlToObject(xmlTest);
            String xmlTest2 = test2.objectToXML();
            verifyXML(xmlTest, xmlTest2, true);
        /* Verifying Test */


//        Content content = new Content();
//        System.out.println(content.objectToXML());
//
//        Test test = new Test(2,"kuku","Subject\\mypctests", "sa", "8-29-2018");
//        System.out.println(test.objectToXML());


        //        JAXBContext jc = JAXBContext.newInstance(Test.class);
//
//        Test rootElement = new Test();
//        java.io.StringWriter sw = new StringWriter();
//
//        Test testCreateRequest = new Test(2,"kuku","Subject\\mypctests", "sa", "8-29-2018");
//        Marshaller marshaller = jc.createMarshaller();
//        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
////        marshaller.setProperty(Marshaller.JAXB_SCHEMA_LOCATION, "http://www.mysite.com/abc.xsd");
//
//        marshaller.marshal(testCreateRequest, System.out);
//        marshaller.marshal(testCreateRequest, sw);
//
//        //create string
//        String xml=sw.toString();
//        xml=xml.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
//        System.out.println("xml is \n" + xml);
//
//
//        //create file
//        String filepath = "src/test/resources/microfocus/adm/performancecenter/plugins/common/rest/Test.xml";
//        File xmlFile = new File(filepath);
//        marshaller.marshal(testCreateRequest, xmlFile);
//        System.out.println("Filename " + xmlFile.getAbsolutePath() + "was created");
//
//
//        //unmarshall file
//        Unmarshaller unmarshaller = this.context.createUnmarshaller();
//        Object unmarshalled = unmarshaller.unmarshal(new File(filepath));
//
//        System.out.println("unmarshalled = " + unmarshalled);
//
//        //create string
//        JAXBContext jaxbContext = JAXBContext.newInstance(Test.class);
//        JAXBElement<Test> element = new JAXBElement<Test> (new QName(PcRestProxy.PC_API_XMLNS,"Test"), Test.class, testCreateRequest2);
//        Marshaller marshaller2 = jaxbContext.createMarshaller();
//        marshaller2.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
//        marshaller2.marshal(element, System.out);


    }

    private void verifyXML(String xmlFromFirstObject, String xmlFromFirstObject2) {
        verifyXML(xmlFromFirstObject, xmlFromFirstObject2, false);
    }

    private void verifyXML(String xmlFromFirstObject, String xmlFromFirstObject2, boolean publish) {
        if (!xmlFromFirstObject.equals(xmlFromFirstObject2))
            System.out.println(String.format("objectToXML doesn't work: original is: \n %s \n and copy is: \n %s \n", xmlFromFirstObject, xmlFromFirstObject2));
        else if(publish)
            System.out.println(xmlFromFirstObject);
    }


}
