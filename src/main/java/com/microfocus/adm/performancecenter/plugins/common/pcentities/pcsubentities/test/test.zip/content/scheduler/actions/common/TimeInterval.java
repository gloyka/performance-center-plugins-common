package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.scheduler.actions.common;


import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.monitorsofw.MonitorOFW;
import com.microfocus.adm.performancecenter.plugins.common.utils.Helper;
import com.thoughtworks.xstream.XStream;
import lombok.Getter;
import lombok.Setter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Setter
@Getter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="TimeInterval")
public class TimeInterval {

    @XmlElement
    private int Days;

    @XmlElement
    private int Hours;

    @XmlElement
    private int Minutes;

    @XmlElement
    private int Seconds;

    public TimeInterval() {}

    public TimeInterval(int days, int hours, int minutes, int seconds) {
        setDays(days);
        setHours(hours);
        setMinutes(minutes);
        setSeconds(seconds);
    }

    public TimeInterval(int hours, int minutes, int seconds) {
        setHours(hours);
        setMinutes(minutes);
        setSeconds(seconds);
    }

    @Override
    public String toString() {
        return "TimeInterval{" +"Days = " + Days +
                ", Hours = " + Hours +
                ", Minutes = " + Minutes +
                ", Seconds = " + Seconds + "}";
    }

    public String objectToXML() {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        xstream.alias("TimeInterval", TimeInterval.class);
        xstream.aliasField("Days", TimeInterval.class, "Days");
        xstream.aliasField("Hours", TimeInterval.class, "Hours");
        xstream.aliasField("Minutes", TimeInterval.class, "Minutes");
        xstream.aliasField("Seconds", TimeInterval.class, "Seconds");
        xstream.aliasField("TimeInterval", TimeInterval.class, "TimeInterval");
        xstream.setMode(XStream.NO_REFERENCES);
        return xstream.toXML(this);
    }

    public static TimeInterval xmlToObject(String xml)
    {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        xstream.alias("TimeInterval" , TimeInterval.class);
        xstream.setClassLoader(TimeInterval.class.getClassLoader());
        xstream.setMode(XStream.NO_REFERENCES);
        return (TimeInterval)xstream.fromXML(xml);
    }
}
