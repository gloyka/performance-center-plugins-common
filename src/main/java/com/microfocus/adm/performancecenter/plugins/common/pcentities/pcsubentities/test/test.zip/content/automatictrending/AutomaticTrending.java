package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.automatictrending;

import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.analysistemplate.AnalysisTemplate;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums.TrendRangeType;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums.MaxRunsReachedOption;
import com.microfocus.adm.performancecenter.plugins.common.utils.Helper;
import com.thoughtworks.xstream.XStream;
import lombok.Getter;
import lombok.Setter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Setter
@Getter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="AutomaticTrending")
public class AutomaticTrending {

    @XmlElement
    private int ReportId;

    @XmlElement
    private int MaxRunsInReport;

    /*Possible values: CompleteRun, PartOfRun*/
    @XmlElement
    private String  TrendRangeType;

    /*Possible values: DoNotPublishAdditionalRuns, DeleteFirstSetNewBaseline.*/
    @XmlElement
    private String MaxRunsReachedOption;

    public AutomaticTrending() {}

    public AutomaticTrending(int reportId, int maxRunsInReport, TrendRangeType trendRangeType, MaxRunsReachedOption maxRunsReachedOption) {
        setReportId(reportId);
        setMaxRunsInReport(maxRunsInReport);
        setTrendRangeType(trendRangeType);
        setMaxRunsReachedOption(maxRunsReachedOption);
    }

    public AutomaticTrending(int reportId, int maxRunsInReport, String trendRangeType, String maxRunsReachedOption) {
        setReportId(reportId);
        setMaxRunsInReport(maxRunsInReport);
        setTrendRangeType(trendRangeType);
        setMaxRunsReachedOption(maxRunsReachedOption);
    }

    public void setTrendRangeType(String trendRangeType) {
        this.TrendRangeType = trendRangeType;
    }

    public void setTrendRangeType(TrendRangeType trendRangeType) {
        this.TrendRangeType = trendRangeType.value();
    }

    public void setMaxRunsReachedOption(String maxRunsReachedOption) {
        this.MaxRunsReachedOption = maxRunsReachedOption;
    }


    public void setMaxRunsReachedOption(MaxRunsReachedOption maxRunsReachedOption) {
        this.MaxRunsReachedOption = maxRunsReachedOption.value();
    }

    @Override
    public String toString() {
        return "AutomaticTrending{" + "ReportId = " + ReportId +
                ", MaxRunsInReport = " + MaxRunsInReport +
                ", TrendRangeType = " + TrendRangeType +
                ", MaxRunsReachedOption = " + MaxRunsReachedOption + "}";
    }


    public String objectToXML() {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        //xstream.useAttributeFor(Content.class, "xmlns");
        xstream.alias("AutomaticTrending", AutomaticTrending.class);
        xstream.aliasField("ReportId", AutomaticTrending.class, "ReportId");
        xstream.aliasField("MaxRunsInReport", AutomaticTrending.class, "MaxRunsInReport");
        xstream.aliasField("TrendRangeType", AutomaticTrending.class, "TrendRangeType");
        xstream.aliasField("MaxRunsReachedOption", AutomaticTrending.class, "MaxRunsReachedOption");
        xstream.aliasField("AnalysisTemplate", AutomaticTrending.class, "AnalysisTemplate");
        xstream.setMode(XStream.NO_REFERENCES);
        return xstream.toXML(this);
    }

    public static AutomaticTrending xmlToObject(String xml)
    {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        xstream.alias("AutomaticTrending" , AutomaticTrending.class);
        xstream.setClassLoader(AutomaticTrending.class.getClassLoader());
        xstream.setMode(XStream.NO_REFERENCES);
        return (AutomaticTrending)xstream.fromXML(xml);
    }

}
