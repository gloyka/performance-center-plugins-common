package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.goalscheduler.goalvirtualusers;


import com.microfocus.adm.performancecenter.plugins.common.utils.Helper;
import com.thoughtworks.xstream.XStream;
import lombok.Setter;
import lombok.Getter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Setter
@Getter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="GoalVirtualUsers")
public class GoalVirtualUsers {

    @XmlElement
    private int TargetVusersNumber;

    public GoalVirtualUsers() { }

    public GoalVirtualUsers(int targetVusersNumber) {
        setTargetVusersNumber(targetVusersNumber);
    }

    @Override
    public String toString() {
        return "GoalVirtualUsers{" +
                "TargetVusersNumber = " + TargetVusersNumber +
                "}";
    }

    public String objectToXML() {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        //xstream.useAttributeFor(Content.class, "xmlns");
        xstream.alias("GoalVirtualUsers", GoalVirtualUsers.class);
        xstream.aliasField("TargetVusersNumber", GoalVirtualUsers.class, "TargetVusersNumber");
        xstream.aliasField("GoalVirtualUsers", GoalVirtualUsers.class, "GoalVirtualUsers");
        xstream.setMode(XStream.NO_REFERENCES);
        return xstream.toXML(this);
    }

    public static GoalVirtualUsers xmlToObject(String xml) {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        xstream.alias("GoalVirtualUsers" , GoalVirtualUsers.class);
        xstream.setClassLoader(GoalVirtualUsers.class.getClassLoader());
        xstream.setMode(XStream.NO_REFERENCES);
        return (GoalVirtualUsers)xstream.fromXML(xml);
    }
}
