package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.scheduler.actions.stopvusers;

import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.content.scheduler.actions.common.Ramp;
import com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums.StartStopVusersType;
import com.microfocus.adm.performancecenter.plugins.common.utils.Helper;
import com.thoughtworks.xstream.XStream;
import lombok.Getter;
import lombok.Setter;

import javax.xml.bind.annotation.*;


@Setter
@Getter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="StopVusers")
public class StopVusers {

    /* possible values:
        Type="simultaneously"
        Type="gradually" */

    @XmlAttribute
    private String Type;

    @XmlElement
    private int Vusers;

    @XmlElement
    private Ramp Ramp;

    public StopVusers(String type, int vusers, Ramp ramp) {
        setType (type);
        setVusers(vusers);
        setRamp(ramp);
    }

    public StopVusers(StartStopVusersType type, int vusers, Ramp ramp) {
        setType (type);
        setVusers(vusers);
        setRamp(ramp);
    }

    public void setType(String type) {
        this.Type = type;
    }

    public void setType(StartStopVusersType type) {
        this.Type = type.value();
    }

    @Override
    public String toString() {
        return "StopVusers{" + "Type = " + Type +
                ", Vusers = " + Vusers +
                ", Ramp = " + Ramp + "}";
    }

    public String objectToXML() {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);
        xstream.alias("StopVusers", StopVusers.class);

        xstream.useAttributeFor(StopVusers.class, "Type");
        xstream.aliasField("Type", StopVusers.class, "Type");

        xstream.aliasField("Vusers", StopVusers.class, "Vusers");
        xstream.aliasField("Ramp", StopVusers.class, "Ramp");
        xstream.aliasField("StopVusers", StopVusers.class, "StopVusers");
        xstream.setMode(XStream.NO_REFERENCES);
        return xstream.toXML(this);
    }

    public static StopVusers xmlToObject(String xml) {
        XStream xstream = new XStream();
        xstream = Helper.xstreamPermissions(xstream);

        xstream.useAttributeFor(StopVusers.class, "Type");
        xstream.aliasField("Type", StopVusers.class, "Type");

        xstream.alias("StopVusers" , StopVusers.class);
        xstream.setClassLoader(StopVusers.class.getClassLoader());
        xstream.setMode(XStream.NO_REFERENCES);
        return (StopVusers)xstream.fromXML(xml);
    }
}
