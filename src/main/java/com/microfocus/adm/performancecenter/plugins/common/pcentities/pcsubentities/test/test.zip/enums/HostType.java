package com.microfocus.adm.performancecenter.plugins.common.pcentities.pcsubentities.test.enums;

public enum HostType {

    SPECIFIC("specific"),
    AUTOMATCH("automatch"),
    DYNAMIC("dynamic");

    private String value;

    private HostType(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }


    public static HostType get(String val){
        for (HostType hostType : HostType.values()) {
            if (val.equals(hostType.value()))
                return hostType;
        }
        return null;
    }

}
