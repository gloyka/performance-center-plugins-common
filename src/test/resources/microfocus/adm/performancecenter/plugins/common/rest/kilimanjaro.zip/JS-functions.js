//
// To view/edit the script, click the Develop Script button
//
// This file defines the data and functions that will be used by EvalJavaScript
// steps in the script
